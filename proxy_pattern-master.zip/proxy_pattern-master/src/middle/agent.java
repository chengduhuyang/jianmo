package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2721:44
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public interface agent {
    public  void  buy_folwers();
    public void  buy_chocolate();
    public void sent_money();
}
