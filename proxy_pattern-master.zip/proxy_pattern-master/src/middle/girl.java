package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2721:33
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class girl {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
