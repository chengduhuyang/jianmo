package primary;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2721:33
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class persuit {
    girl mm;

    public persuit(girl mm) {
        this.mm = mm;
    }
    public  void  buy_folwers(){
        System.out.println("买玫瑰花");
    }
    public void  buy_chocolate(){
        System.out.println("买巧克力");
    }
    public void sent_money(){
        System.out.println("送女朋友钱");
    }
}
