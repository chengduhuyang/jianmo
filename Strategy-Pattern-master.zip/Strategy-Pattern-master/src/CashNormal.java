/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/4/2217:12
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class CashNormal implements CashSuper{

    @Override
    public double acceptCash(double money)
    {

        return money;
    }

}
