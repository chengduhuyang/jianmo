package middle;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/921:42
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class Astudent extends paper {
    public void question1(){
       super.question1();
        System.out.println("1.1");
    }
    public void question2(){
        super.question2();
        System.out.println("1.1");
    }
    public  void  question3(){
        super.question3();
        System.out.println("1.1");
    }
}
