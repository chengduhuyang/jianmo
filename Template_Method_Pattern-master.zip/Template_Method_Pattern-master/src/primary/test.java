package primary;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/921:45
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class test {
    public static void main(String[] args) {
        Astudent a= new Astudent();
        a.question1();
        a.question2();
        a.question3();
        Bstudent b= new Bstudent();
        b.question1();
        b.question2();
        b.question3();
    }
}
