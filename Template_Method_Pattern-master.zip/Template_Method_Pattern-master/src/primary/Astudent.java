package primary;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/921:42
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class Astudent {
    public void question1(){
        System.out.println("A1.a");
        System.out.println("1.1");
    }
    public void question2(){
        System.out.println("A2.b");
        System.out.println("1.1");
    }
    public  void  question3(){
        System.out.println("A3.c");
        System.out.println("1.1");
    }
}
