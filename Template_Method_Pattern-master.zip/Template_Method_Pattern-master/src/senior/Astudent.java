package senior;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/922:02
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class Astudent extends paper {
    @Override
    protected String answer1() {
        return "a.1";
    }

    @Override
    protected String answer2() {
        return "A.2";
    }

    @Override
    protected String answer3() {
        return "A.3";
    }
}
