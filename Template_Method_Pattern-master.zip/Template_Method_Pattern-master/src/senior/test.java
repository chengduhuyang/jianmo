package senior;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/922:04
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class test {
    public static void main(String[] args) {
        Astudent a = new Astudent();
        a.question1();
        a.question2();
        a.question3();

    }
}
