package senior;

/**
 * 功能描述：
 *
 * @Author：cqf
 * @2020/5/922:03
 * @description： TODO
 * @modifiedBy：
 * @version: 1.0
 **/
public class Bstudent extends paper {
    @Override
    protected String answer1() {
        return "B.1";
    }

    @Override
    protected String answer2() {
        return "B.2";
    }

    @Override
    protected String answer3() {
        return "B.3";
    }
}
